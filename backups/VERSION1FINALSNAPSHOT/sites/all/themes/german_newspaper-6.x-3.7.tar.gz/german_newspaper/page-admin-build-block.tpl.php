<?php
// $Id: page-admin-build-block.tpl.php,v 1.1 2009/06/07 12:01:38 christiangnoth Exp $
?>
<?php require('page.tpl.php');