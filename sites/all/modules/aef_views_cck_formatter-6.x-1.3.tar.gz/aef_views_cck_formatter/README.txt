Views CCK Formatter
===================

This module works with Views and CCK. It allows one view to use a CCK nodereference formatter (basically a node theme) to theme results of a View.

* Works on views provided by modules
------------------------------------
You can provide a View in your module using this feature. But please note that you won't find any admin interface unless you install Views UI!

* Works on views made directly on the view admin panel
------------------------------------------------------
You will need Views UI for that. Edit your view, go to "Row Style", select "CCK Formatter" and then your formatter.
