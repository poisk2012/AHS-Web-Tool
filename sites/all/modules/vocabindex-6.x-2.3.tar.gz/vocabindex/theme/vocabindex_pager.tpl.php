<?php
// $Id: vocabindex_pager.tpl.php,v 1.1.2.4 2008/10/19 10:52:59 xano Exp $

/**
 * @file
 * Renders a pager which is used for alphabetical lists.
 *
 * Available variables:
 * $letters The pager items.
 */
?>
<div class="vocabindex-pager"><?php echo $letters?></div>