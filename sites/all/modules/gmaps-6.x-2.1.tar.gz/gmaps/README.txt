// $Id: README.txt,v 1.1.2.4 2010/03/04 17:18:38 xmarket Exp $

===============================================================================
Google Maps Tools
===============================================================================
Welcome on Google Maps!

This project lets you use the well known Google Maps API and
Google Static Maps API on your site.


You can read more about the project at:
http://www.gmaps-tools.com/


===============================================================================
Maintainer
===============================================================================
István Németh <i.nemeth@xmarket.hu>
              http://drupal.org/user/231445
