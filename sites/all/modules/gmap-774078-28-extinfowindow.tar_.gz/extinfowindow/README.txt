/* $Id$ */

ExtInfoWindow
--------------
Extinfowindow plugin by Joe Monahan.
Integration of the extinfowindow plugin with gmap by Arshad Chummun.

Usage
--------------
You must download the plugin from http://gmaps-utility-library-dev.googlecode.com/svn/tags/extinfowindow/1.2/src/
You can enable extinfowindow and select a theme to use on the gmap settings page.

Theming
--------------
To create a new theme for extinfowindow:
1. Create a new directory in your theme called extinfowindow
2. Copy one of the the default themes (example: light) into the extinfowindow directory of your theme.
3. Rename the folder to your theme name (example: mytheme).
4. Rename light.css to yourthemename.css (example: mytheme.css)
5. Edit the css in the css file (images goes inside the images directory)

Note that if you do not rename your theme's directory and css file the theme will override the default theme you copied.
