Draggableviews
---------------
This module provides a style plugin for views. This plugin allows dragging nodes and saving the new structure.

Quick install:
 1) Activate Draggableviews module at yoursite?q=admin/build/modules.
 2) Navigate to views edit-page and Click the "+" at the "Fields" section and
    choose "Draggableviews: Order" -> Click Add button.
 3) Click the currently enabled style plugin ("Basic settings" section).
    Choose Draggable Table and click Update button.
 4) Enter style plugin settings by clicking the little cogwheel next to "Draggable Table" style plugin
 5) Set the Order Field from 2) and choose "Native" handler.
    Click Update button.
 6) Save the view and you're done.
