<?php
// $Id: draggableviews-view-draggabletable-form.tpl.php,v 1.6.2.3 2009/08/19 12:28:38 sevi Exp $

/**
 * @file
 * Template to merge the views output with some module-specific output.
 *
 * - $view: The view output.
 * - $form: All rendered form elements.
 */

print $view;
print $form;
