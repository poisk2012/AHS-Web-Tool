In-place popup to add a new node to Node Reference widget.
Initial inspiration: Add and Reference by tema (http://drupal.org/project/add_n_reference)

TODO 
 * Fix losing highlighted selections on node add with multi-select box.
 
LIMITATIONS
 * http://drupal.org/node/378988 - conflicts with Hierarchical Select.

 