/* $Id$ */

extinfowindow.js
------------
Implementation of the extinfowindow plugin by Arshad Chummun.

Theming
------------
To create a new theme for extinfowindow : 
1. Copy the default theme light.
2. Rename the folder to your theme name (example : mytheme)
3. Rename light.css to yourthemename.css (example : mytheme.css)
4. Edit the css in the css file (images goes inside the images directory)

Your new theme will appear under extinfowindow settings.
