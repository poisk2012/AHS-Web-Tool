$Id: README.txt,v 1.1 2007/03/18 02:55:08 webchick Exp $

This theme is a Drupal implementation of the Blue Zinfandel Squared Enhanced
2.0 WordPress theme by Brian Gardner:
http://www.briangardner.com/themes/blue-zinfandel-squared-wordpress-theme.htm

Currently, it is a fixed-width theme that supports only two columns, so is best
suited to simple blogs. Eventually, I would like to also incorporate Brian's
original Blue Zinfandel 2.0 theme:
http://www.briangardner.com/themes/blue-zinfandel-wordpress-theme.htm

This would provide a theme that could dynamically switch between two and three
columns, fixed- and fluid width. Or maybe port the whole dang thing to Zen; 
not sure yet. ;) This is my first Drupal theme, so please be kind. ;)

Anyway, for now, enjoy! And thanks, Brian for the great theme!

